import WhoToFollowListItem from "./WhoToFollowListItem.js"
const WhoToFollowList = () => {  
   return (WhoToFollowListItem); }
export default WhoToFollowList;

